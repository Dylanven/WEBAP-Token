﻿using System;
using System.Collections.Generic;

namespace projetAPI2.Models;

public partial class StatesTask
{
    public int IdStatesTask { get; set; }

    public string StaTaName { get; set; } = null!;
}
