﻿using System;
using System.Collections.Generic;

namespace projetAPI2.Models;

public partial class UserNotification
{
    public int IdUser { get; set; }

    public int IdNotification { get; set; }
}
