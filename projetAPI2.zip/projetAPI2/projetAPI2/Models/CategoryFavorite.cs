﻿using System;
using System.Collections.Generic;

namespace projetAPI2.Models;

public partial class CategoryFavorite
{
    public int IdCategory { get; set; }

    public int IdUser { get; set; }
}
