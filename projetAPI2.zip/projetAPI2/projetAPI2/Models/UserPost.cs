﻿using System;
using System.Collections.Generic;

namespace projetAPI2.Models;

public partial class UserPost
{
    public int IdUser { get; set; }

    public int IdPost { get; set; }
}
