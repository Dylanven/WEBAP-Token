﻿using System;
using System.Collections.Generic;

namespace projetAPI2.Models;

public partial class UserEvent
{
    public int IdUser { get; set; }

    public int IdEvent { get; set; }

    public int IdRole { get; set; }
}
