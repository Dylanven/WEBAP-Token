﻿using System;
using System.Collections.Generic;

namespace projetAPI2.Models;

public partial class EventRole
{
    public int IdRole { get; set; }

    public string RolName { get; set; } = null!;
}
