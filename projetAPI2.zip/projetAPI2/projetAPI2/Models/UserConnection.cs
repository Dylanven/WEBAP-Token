﻿using System;
using System.Collections.Generic;

namespace projetAPI2.Models;

public partial class UserConnection
{
    public int IdUser { get; set; }

    public int IdConnection { get; set; }
}
