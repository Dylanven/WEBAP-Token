﻿using System;
using System.Collections.Generic;

namespace projetAPI2.Models;

public partial class UserTask
{
    public int IdUser { get; set; }

    public int IdTask { get; set; }
}
