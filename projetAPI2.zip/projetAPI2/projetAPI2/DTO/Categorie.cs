﻿namespace projetAPI2.DTO
{
    public class Categorie
    {

        public string CatName { get; set; } = null!;
    }
}
